# 木子AI网站（GitHub Pages版）

这是一个纯静态内容网站，可部署在 **GitHub Pages / Netlify / Cloudflare Pages** 上。  
主打 **ChatGPT / Sora / AI 工具教程与代充引导文章**，设计风格简洁白底卡片化。

---

## 🚀 部署方法
1. 下载整个项目文件夹 `muzi-ai/`
2. 上传至你的 GitHub 仓库（例如 `yourname/muzi-ai`）
3. 进入仓库 → Settings → Pages → 选择 main 分支 `/ (root)` → 保存
4. 稍等几分钟后，访问：
